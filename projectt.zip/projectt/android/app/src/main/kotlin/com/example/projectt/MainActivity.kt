package com.example.projectt

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
